package com.blogging.app.blogging.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BloggingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
